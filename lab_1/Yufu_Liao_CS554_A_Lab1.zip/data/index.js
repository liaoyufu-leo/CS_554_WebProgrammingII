const userData = require('./user');
const blogData = require('./blog');
const commentData = require('./comment');

module.exports = {
    user: userData,
    blog: blogData,
    comment:commentData
};
